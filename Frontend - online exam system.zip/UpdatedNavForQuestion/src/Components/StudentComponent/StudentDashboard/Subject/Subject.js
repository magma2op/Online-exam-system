import style from "../StudentDashboard.module.css";
import { useHistory } from "react-router-dom";

import { useState, useEffect } from "react";
import axios from "axios";

import { NavLink } from "react-router-dom";

import baseUrl from "../../../baseUrl";

function Subject() {
  const [allSubject, setAllSubject] = useState([]);

  useEffect(() => {
    async function getAllSubject() {
      let value = await axios.get(`${baseUrl}/subject`);
      setAllSubject(value.data);
    }
    getAllSubject();
  }, []);
  let history = useHistory();

  function logout() {
    sessionStorage.clear();
    history.push("/StudentLogin");
  }

  return (
    <>
      {/* This is the header Div start*/}
      <div className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div className="container-fluid">
          <h2 className="text-white"> Online Exam System</h2>

          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div
            className="collapse navbar-collapse justify-content-end"
            id="navbarNav"
          >
            <ul className="navbar-nav justify-content-end">
              <li className="nav-item">
                <NavLink exact to="/StudentDashboard" className="nav-link">
                  Subject
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  exact
                  to="/StudentDashboard/Result"
                  className="nav-link"
                >
                  My Result
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  onClick={logout}
                  exact
                  to="/StudentLogin"
                  className="nav-link"
                >
                  Logout
                </NavLink>
              </li>
            </ul>
          </div>
        </div>
      </div>
      {/* This is the header Div end*/}

      <div id={style.displayBoxHeadingBox}>
        <h1>Choose Subjects</h1>
      </div>

      {allSubject.map((data, i) => {
        return (
          <div id={style.displayBoxSubjectBox} key={i}>
            <div id={style.subjectText}>
              <span>{data.name}</span>
            </div>

            <div id={style.subjectButton}>
              <NavLink exact to={`/StudentDashboard/Exam/${data.name}`}>
                <button className="btn btn-light btn-outline-dark">
                  Go to Exam
                </button>
              </NavLink>
            </div>
          </div>
        );
      })}
    </>
  );
}

export default Subject;
