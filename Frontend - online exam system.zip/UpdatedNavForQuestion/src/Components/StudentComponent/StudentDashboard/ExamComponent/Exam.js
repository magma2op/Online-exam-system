import axios from "axios";
import { useHistory } from "react-router-dom";

import React, { useState, useEffect } from "react";
import { useParams, NavLink } from "react-router-dom";

import style from "../StudentDashboard.module.css";

import baseUrl from "../../../baseUrl";

function Exam() {
  let { category } = useParams();

  const [allExam, setAllExam] = useState([]);

  useEffect(() => {
    async function getAllExams() {
      let value = await axios.get(`${baseUrl}/exam`);
      setAllExam(value.data);
      // console.log(value.data);
    }
    getAllExams();
  }, []);
  let history = useHistory();

  function logout() {
    sessionStorage.clear();
    history.push("/StudentLogin");
  }

  return (
    <>
      {/* This is the header Div start*/}
      <div className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div className="container-fluid">
          <h2 className="text-white"> Online Exam System</h2>

          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div
            className="collapse navbar-collapse justify-content-end"
            id="navbarNav"
          >
            <ul className="navbar-nav justify-content-end">
              <li className="nav-item">
                <NavLink exact to="/StudentDashboard" className="nav-link">
                  Subject
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  exact
                  to="/StudentDashboard/Result"
                  className="nav-link"
                >
                  My Result
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  onClick={logout}
                  exact
                  to="/StudentLogin"
                  className="nav-link"
                >
                  Logout
                </NavLink>
              </li>
            </ul>
          </div>
        </div>
      </div>
      {/* This is the header Div end*/}

      <div id={style.displayBoxHeadingBox}>
        <h1>All {category} Exam</h1>
      </div>
      {allExam.map((data, i) => {
        if (data.name.name === category)
          return (
            <div id={style.displayBoxExamBox} key={i}>
              <div id={style.div1}>
                {" "}
                <span>{data.name.name}</span>{" "}
              </div>
              <div id={style.div2}>
                {" "}
                <span>Exam ID: {data.id}</span>{" "}
              </div>
              <div id={style.div2}>
                {" "}
                <span>Exam Description: {data.desc}</span>{" "}
              </div>
              <div id={style.div3}>
                <span>Pass Marks:{data.passMarks}</span>{" "}
              </div>
              <div id={style.div4}>
                <span>Total Marks:{data.marks}</span>
              </div>
              <div id={style.div5}>
                <NavLink
                  exact
                  to={`/StudentDashboard/Exam/${category}/${data.id}`}
                >
                  <button>Go to Exam</button>
                </NavLink>
              </div>
            </div>
          );

        return <React.Fragment key={i}></React.Fragment>;
      })}
    </>
  );
}
export default Exam;
