import style from "./Home.module.css";

//  import pic4 from "../../images/5.jpg";
import { NavLink } from "react-router-dom";

function Home() {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "100vh",
      }}
    >
      <div>
        <div id={style.background1}>
          {/* <div className="text-center"> */}
          {/* <div className="header  d-flex ">
              <div className="" id={style.name}>
                <h3 className="text-white ">Online Exam System</h3>
              </div>
            </div> */}
          <div className="mb-3" id={style.buttondiv}>
            <NavLink
              exact
              to="/StudentLogin"
              className="btn btn-primary"
              id={style.buttoncenter}
            >
              <span className="text-white">Student</span>
            </NavLink>
            <NavLink
              to="/AdminLogin"
              className="card-link btn btn-primary"
              id={style.buttoncenter}
            >
              <span className="text-white">Teacher</span>
            </NavLink>
            <NavLink
              exact
              to="/RootLogin"
              className="card-link btn btn-primary"
              id={style.buttoncenter}
            >
              <span className="text-white">Admin</span>
            </NavLink>
          </div>
          <div className="mb-3"></div>
          <div className="mb-3"></div>
        </div>
      </div>
      {/* <img src={pic4} alt="" style={{ width: '100%', height: 'auto' }} /> */}
    </div>
    // </div>
  );
}
export default Home;
