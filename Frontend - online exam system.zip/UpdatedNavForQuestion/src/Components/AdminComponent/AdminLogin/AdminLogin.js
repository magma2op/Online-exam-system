import style from "./AdminLogin.module.css";

import { NavLink } from "react-router-dom";

import { useState } from "react";

import axios from "axios";

import { useHistory } from "react-router-dom";

import baseUrl from "../../baseUrl";

function AdminLogin() {
  const [admin, setAdmin] = useState({
    admin_name: "",
    admin_password: "",
  });

  function handleInput(e) {
    setAdmin(
      {
        ...admin,
        [e.target.name]: e.target.value,
      },
      []
    );
  }
  let history = useHistory();

  async function login(e) {
    try {
      const value = await axios.get(`${baseUrl}/admin/${admin.admin_name}`);
      if (value.data.name === admin.admin_name) {
        if (value.data.password === admin.admin_password) {
          alert("success");
          history.push("/AdminDashboard");
        } else {
          alert("Wrong Password");
        }
      } else {
        alert("Wrong Teacher name");
      }
    } catch (e) {
      alert("Teacher Does not exist, try other user name in again");
    }
  }

  return (
    <>
      <div className="container-fluid" id={style.background1}>
        <div className="col-md-6" id={style.loginbox}>
          <div
            className="form-control"
            // style={{ backgroundColor: "transparent", border: "none" }}
            id={style.form1}
          >
            <h2
              className="display-4"
              id={style.adminbox1}
              style={{ color: "white" }}
            >
              <b>Teacher Login</b>
            </h2>
            <label htmlFor="email" id={style.adminname}>
              {" "}
              <h3 className="" style={{ color: "white" }}>
                Teacher Name
              </h3>
              <input
                className=" form-control-lg"
                name="admin_name"
                onChange={(e) => handleInput(e)}
                type="text"
                id={style.email}
                placeholder="enter teacher name"
                required
              />
            </label>

            <label htmlFor="password" id={style.password1}>
              {" "}
              <h3 style={{ color: "white" }}>Password</h3>
              <input
                className=" form-control-lg"
                name="admin_password"
                onChange={(e) => handleInput(e)}
                type="password"
                id={style.password}
                placeholder="enter password"
                required
              />
            </label>
            <br />
            <br />

            <button
              onClick={(e) => login(e)}
              className="btn btn-primary btn-center "
              id={style.login1}
            >
              Login
            </button>
            <span> </span>
            <button className="btn btn-primary btn-center ">
              <NavLink
                to="/"
                style={{ textDecoration: "none", color: "white" }}
              >
                {" "}
                Go Back
              </NavLink>{" "}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export default AdminLogin;
